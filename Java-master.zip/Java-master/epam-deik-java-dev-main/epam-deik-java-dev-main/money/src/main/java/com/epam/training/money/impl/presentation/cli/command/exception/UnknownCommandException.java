package com.epam.training.money.impl.presentation.cli.command.exception;

public class UnknownCommandException extends RuntimeException{

}
