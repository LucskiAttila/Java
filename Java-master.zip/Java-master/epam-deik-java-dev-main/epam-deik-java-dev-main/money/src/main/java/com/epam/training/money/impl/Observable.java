package com.epam.training.money.impl;

public interface Observable {
    void subscribe(Observer observer);
}
