package com.epam.training.money.impl;

import java.util.List;

public interface ProductRepository {
    public List<Product> getAllProduct();
}
