package com.epam.training.money.impl.command;

public interface Command {
    String execute();
}
