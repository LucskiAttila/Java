package com.epam.training.money.impl;

public interface Product {
    double getValue();
}
