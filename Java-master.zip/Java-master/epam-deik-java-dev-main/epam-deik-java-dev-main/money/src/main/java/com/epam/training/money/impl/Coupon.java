package com.epam.training.money.impl;

public interface Coupon {

}
