# Java development in practice

This is a repository containing resources and materials for the 'Java development in
practice' course.