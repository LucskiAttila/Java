package com.epam.training.ticketservice.logic.command.price.baseprice;

public enum BasePriceProperties {
    base_price
}
