package com.epam.training.ticketservice.logic.command;

public interface Text {
    String capitalize(String word);
    String getType();
}
