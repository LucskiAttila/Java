package com.epam.training.ticketservice.logic.command.room;

public enum RoomProperties {
    numberOfRowsOfChairs,
    numberOfColumnsOfChairs,
    price_component,
    room;
}
