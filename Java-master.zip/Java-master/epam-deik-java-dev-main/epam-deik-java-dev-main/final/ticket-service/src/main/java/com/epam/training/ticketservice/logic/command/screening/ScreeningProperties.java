package com.epam.training.ticketservice.logic.command.screening;

public enum ScreeningProperties {
    title,
    roomName,
    overlap,
    breaking,
    price_component,
    screening;
}
