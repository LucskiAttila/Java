package com.epam.training.ticketservice.logic.command.movie;

public enum MovieProperties {
    genre,
    durationInMinutes,
    price_component,
    movie;
}
