package com.epam.training.ticketservice.logic.command;

public interface Command {
    String execute();
}
