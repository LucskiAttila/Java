package com.epam.training.ticketservice.logic.command.price.pricecomponent;

public enum PriceComponentProperties {
    price_component
}
